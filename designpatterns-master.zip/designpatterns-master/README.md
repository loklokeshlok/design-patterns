# designpatterns
