package epam.prototype;
public interface Prototype {

	public Prototype getClone();
	
}