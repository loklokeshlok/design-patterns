package epam.designpatterns;
public interface CreditCard {
	
	public void giveBankDetails();
	public String getCreditCard();

}