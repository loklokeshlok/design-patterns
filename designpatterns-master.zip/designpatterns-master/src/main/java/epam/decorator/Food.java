package epam.decorator;
public interface Food {

	public double foodPrice();
	public String prepareFood();

}