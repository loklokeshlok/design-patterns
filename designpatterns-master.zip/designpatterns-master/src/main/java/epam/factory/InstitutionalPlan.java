package epam.factory;
public class InstitutionalPlan extends Plan {

	public void getRate() {
		rate = 5.50;
	}
	
}