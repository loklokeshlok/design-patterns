package epam.factory;
public class CommercialPlan extends Plan {

	public void getRate() {
		rate = 7.50;		
	}
	
}